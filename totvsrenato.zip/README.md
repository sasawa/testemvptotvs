# Renato Preuss Montanholi

Este projeto foi desenvolvido na versão do Node.JS 13.9.0

Como dependencia global é necessario o uso do json-server para que seja mockado um servidor de banco de dados, é mais pratico para uma demonstração do que ser levantado todo um backend para uma população simples.

### `npm install json-server -g`

Em seguida use o comando 
### `json-server --watch db.json --port 3004`

Clone esse repositorio, e instale as dependencias

### `npm install`
Para rodar a aplicação

### `npm start`
